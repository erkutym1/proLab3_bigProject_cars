﻿using System;
using System.ComponentModel.Design;
using System.Collections.Generic;
using System.Diagnostics.Metrics;

namespace CarShoppie
{
    public class Cars
    {
        public string BrandModelName { get; set; }
        public string[] PackageName = new string[2];
        public string[] ToolName = new string[10];
        public int[] ToolWeHaveNumber = new int[10];

        public void carShow(Cars theCar)
        {
            for (int i = 0; i < 2; i++) 
            {
                Console.WriteLine(theCar.BrandModelName);
                Console.WriteLine(theCar.PackageName[i]);

                for (int j = 0; j < 10; j++)
                {
                    Console.WriteLine(theCar.ToolName[i]);
                    Console.WriteLine(theCar.ToolWeHaveNumber[i]);
                }
            }
        }

        public void carDataCreate(Cars theCar)
        {
            string[] carBrandModelFolder = theCar.BrandModelName.Split(" ");
            string carBrandModelFolderName = "";
            for (int filenameWord = 0; filenameWord < carBrandModelFolder.Length; filenameWord++)
            {
                carBrandModelFolderName += carBrandModelFolder[filenameWord];
                if (filenameWord != carBrandModelFolder.Length-1)
                    carBrandModelFolderName += "_";
            }

            carBrandModelFolderName = carBrandModelFolderName.ToLower();

            string NewBrand = carBrandModelFolderName;
            string projectPath = AppDomain.CurrentDomain.BaseDirectory;
            projectPath += "\\theDatabase\\carsTotalData";
            string folderPath = Path.Combine(projectPath, NewBrand);

            if (Directory.Exists(folderPath))
            {
                Console.WriteLine($"Klasör var yenisini olusturmadım: {folderPath}");
            }
            else
            {
                Console.WriteLine($"Klasör yok olusturdum: {folderPath}");
                Directory.CreateDirectory(folderPath);
                // ARABAYI KAYDEDECEK KLASOR OLUSTURULDU
                // SIMDI SIRA DATA DOSYALARINI OLUSTURMAKTA...

                string copyPath = AppDomain.CurrentDomain.BaseDirectory;
                copyPath += "\\theDatabase\\templateFiles_selling";

                string pastePath = AppDomain.CurrentDomain.BaseDirectory;
                pastePath += "\\theDatabase\\carsTotalData\\";
                pastePath += NewBrand.ToString();

                string pastePath1 = pastePath + "\\" + theCar.PackageName[0].ToString();
                string pastePath2 = pastePath + "\\" + theCar.PackageName[1].ToString();

                static void KlasorKopyalaYapistir(string kaynakDizin, string hedefDizin)
                {
                    try
                    {
                        // Kaynak dizini kontrol et
                        if (!Directory.Exists(kaynakDizin))
                        {
                            Console.WriteLine("Kaynak dizin bulunamadı.");
                            return;
                        }

                        // Hedef dizini kontrol et ve oluştur
                        if (!Directory.Exists(hedefDizin))
                        {
                            Directory.CreateDirectory(hedefDizin);
                        }

                        // Kaynak dizinindeki dosyaları ve alt dizinleri kopyala
                        string[] dosyalar = Directory.GetFiles(kaynakDizin);
                        foreach (string dosya in dosyalar)
                        {
                            string dosyaAdi = Path.GetFileName(dosya);
                            string hedefDosyaYolu = Path.Combine(hedefDizin, dosyaAdi);
                            File.Copy(dosya, hedefDosyaYolu, true);
                        }

                        string[] altDizinler = Directory.GetDirectories(kaynakDizin);
                        foreach (string altDizin in altDizinler)
                        {
                            string altDizinAdi = Path.GetFileName(altDizin);
                            string hedefAltDizin = Path.Combine(hedefDizin, altDizinAdi);
                            KlasorKopyalaYapistir(altDizin, hedefAltDizin);
                        }
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine($"Hata oluştu: {ex.Message}");
                    }
                }

                KlasorKopyalaYapistir(copyPath, pastePath1);
                KlasorKopyalaYapistir(copyPath, pastePath2);
                // ARABAMIZI OLUSTURDUK VE ICERISINE DATA DOSYALARINI YERLESTIRDIK


                string newCarNamePath1 = pastePath1 + "\\car_brand_model_name.txt";
                string newCarNamePath2 = pastePath2 + "\\car_brand_model_name.txt";

                Console.WriteLine(newCarNamePath1);
                Console.WriteLine(newCarNamePath2);

                using (StreamWriter carName1 = new StreamWriter(newCarNamePath1))
                {
                    carName1.WriteLine(theCar.BrandModelName + " " + theCar.PackageName[0]);
                }
                using (StreamWriter carName2 = new StreamWriter(newCarNamePath2))
                {
                    carName2.WriteLine(theCar.BrandModelName + " " + theCar.PackageName[1]);
                }

                // ARAC OLUSTURULDU, KLASOR OLUSTURULDU, DATA DOSYALARI EKLENDI...
            }

            




        }

        }


        
 





    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Type 1 = Admin Login");
            Console.WriteLine("Type 2 = Customer Login");
            Console.WriteLine("Type 3 = Dealer Login");
            Console.WriteLine("Type 0 = EXIT");
            Console.WriteLine("Please, select the action you want to take : ");
            int choice;
            while (!(int.TryParse(Console.ReadLine(), out choice) && choice>=0 && choice<=3))
            {
                Console.Clear();
                Console.WriteLine("Invalid selection. Please, try again...");
                Console.WriteLine("Type 1 = Admin Login");
                Console.WriteLine("Type 2 = Customer Login");
                Console.WriteLine("Type 3 = Dealer Login");
                Console.WriteLine("Type 0 = EXIT");
                Console.WriteLine("Please, select the action you want to take : ");
            }
            
            while (true)
            {
                if (choice == 0)
                { 
                    Console.Clear(); 
                    Console.WriteLine("See you again...");
                    break;
                }
                else if (choice == 1) 
                {
                    Console.Clear();
                    Console.WriteLine("admin login basliyooooo");

                    Console.WriteLine("YENİ ARABA MARKASI MODELİ GİR : ");
                    Cars newCar = new Cars();
                    newCar.BrandModelName = Console.ReadLine();

                    Console.WriteLine("VERSION 1 GİR : ");
                    newCar.PackageName[0] = Console.ReadLine();
                    Console.WriteLine("VERSION 2 GİR : ");
                    newCar.PackageName[1] = Console.ReadLine();


                    newCar.carDataCreate(newCar);
                    
                }
                else if (choice == 2)
                {
                    Console.Clear();
                    Console.WriteLine("customer login basliyooo");
                }
                else if (choice == 3)
                {
                    Console.Clear();
                    Console.WriteLine("dealer login basliyooo");
                }
                

                else
                { 
                    Console.Clear();
                    Console.WriteLine("See you again...");
                    break; 
                }

                Console.WriteLine("Do you have any request??");
                Console.WriteLine("Type 1 - YES // Type 2 - No : ");
                int continchoice;
                while (!(int.TryParse(Console.ReadLine(), out continchoice) && continchoice >= 1 && continchoice <= 2))
                {
                    Console.Clear();
                    Console.WriteLine("Invalid selection. Please, try again...");
                    Console.WriteLine("Do you have any request??");
                    Console.WriteLine("Type 1 - YES // Type 2 - No : ");
                }

                if (continchoice == 1)
                {
                    Console.Clear();
                    Console.WriteLine("Type 1 = Admin Login");
                    Console.WriteLine("Type 2 = Customer Login");
                    Console.WriteLine("Type 3 = Dealer Login");
                    Console.WriteLine("Type 0 = EXIT");
                    Console.WriteLine("Please, select the action you want to take : ");
                    choice = 0;
                    while (!(int.TryParse(Console.ReadLine(), out choice) && choice >= 0 && choice <= 3))
                    {
                        Console.Clear();
                        Console.WriteLine("Invalid selection. Please, try again...");
                        Console.WriteLine("Type 1 = Admin Login");
                        Console.WriteLine("Type 2 = Customer Login");
                        Console.WriteLine("Type 3 = Dealer Login");
                        Console.WriteLine("Type 0 = EXIT");
                        Console.WriteLine("Please, select the action you want to take : ");
                    }
                }
                else
                {
                    Console.Clear();
                    Console.WriteLine("See you again...");
                    break;
                }
                    



            }
        }
    }
}